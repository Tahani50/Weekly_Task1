//
//  ExpenseListView.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//
import SwiftUI

struct ExpenseListView: View {
    @ObservedObject var expenseViewModel: ExpenseViewModel  // ViewModel to interact with the expense list
    @State private var isDarkMode: Bool = false  // State to manage dark mode toggle
    
    var body: some View {
        VStack {
            // Category Picker for Filtering Expenses
            Picker("Filter by Category", selection: $expenseViewModel.selectedCategory) {
                Text("All").tag("All")
                Text("Food").tag("Food")
                Text("Travel").tag("Travel")
                Text("Shopping").tag("Shopping")
            }
            .pickerStyle(SegmentedPickerStyle())  // Use a segmented picker style
            .background(isDarkMode ? Color.gray : Color.white)  // Set background color based on dark mode
            .foregroundColor(isDarkMode ? .white : .black)  // Set text color based on dark mode
            .padding()
            
            // Sort Button
            Button(action: {
                expenseViewModel.toggleSortOrder()  // Toggle the sort order when pressed
            }) {
                Text("Sort by Amount \(expenseViewModel.sortedAscending ? "Ascending" : "Descending")")  // Button text shows current sort order
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding()
            
            // Display the list of expenses
            List(expenseViewModel.sortedExpenses().filter { expense in
                expenseViewModel.selectedCategory == "All" || expenseViewModel.selectedCategory == expense.category  // Filter by selected category
            }, id: \.name) { expense in
                VStack(alignment: .leading) {
                    Text(expense.name)
                        .font(.headline)
                    Text("Amount: \(formattedAmount(expense.amount))")
                    Text("Category: \(expense.category)")
                        .foregroundColor(.gray)
                }
            }
        }
    }
    
    // Currency Formatter to display amount in currency format
    private func formattedAmount(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency  // Set the number style to currency
        return formatter.string(from: NSNumber(value: amount)) ?? "$0.00"  // Format the amount and return as a string, defaulting to "$0.00" if formatting fails
    }
}
