//
//  ExpenseModel.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//

import SwiftUI

// Expense Model to represent each expense
struct Expense: Identifiable {
    var id: UUID = UUID()
    var name: String
    var amount: Double
    var category: String
}

