//
//  ContentView.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//

import SwiftUI


struct ContentView: View {
    @ObservedObject var expenseViewModel = ExpenseViewModel()  // ViewModel to manage the expense list
    
    @State private var isDarkMode: Bool = false  // State to manage dark mode toggle
    
    var body: some View {
        NavigationView {
            VStack {
                // Display the app title
                Text("Expense Tracker")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(isDarkMode ? .white : .black)  // Change title color based on dark mode
                
                // Dark Mode Toggle
                Toggle(isOn: $isDarkMode) {
                    Text("Dark Mode")
                        .foregroundColor(isDarkMode ? .white : .black)  // Change label color based on dark mode
                }
                .padding()
                .background(isDarkMode ? .black : .white)  // Set background color based on dark mode
                .cornerRadius(8)
                
                // Display List of Expenses
                ExpenseListView(expenseViewModel: expenseViewModel)
                    .padding()
            }
            .padding()
                // A toolbar with a button to navigate to the Add Expense form
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                        NavigationLink(destination: AddExpenseView(expenseViewModel: expenseViewModel)) {
                                Text("Add")  // Text for the toolbar button
                                .foregroundColor(.blue)  // Change text color based on dark mode
                        }
                }
            }
            
            .background(isDarkMode ? Color.black : Color.white)  // Set background color of the main view based on dark mode
        }
    }
}

