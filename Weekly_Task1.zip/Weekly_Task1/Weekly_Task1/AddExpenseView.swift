//
//  AddExpenseView.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//

import SwiftUI

struct AddExpenseView: View {
    
    @Environment(\.dismiss) private var dismiss
    @State private var expenseName: String = ""   // State to store the expense name
    @State private var expenseAmount: Double = 0.0  // State to store the expense amount
    @State private var selectedCategory: String = "Food"  // State to store the selected category
    
    let categories = ["Food", "Travel", "Shopping"]  // Available expense categories
    
    @ObservedObject var expenseViewModel: ExpenseViewModel  // ViewModel to interact with expenses
    
    var body: some View {
        NavigationStack {
            List {
                // Expense Name Field
                Section(header: Text("Expense name")) {
                    TextField("Enter expense name", text: $expenseName)
                }
                
                // Expense Amount Field
                Section(header: Text("Amount")) {
                    TextField("Enter amount", value: $expenseAmount, formatter: NumberFormatter())
                        .keyboardType(.decimalPad)  // Set the keyboard type to numeric (decimal)
                }
                
                // Category Picker
                Section(header: Text("Category")) {
                    Picker("Select Category", selection: $selectedCategory) {
                        ForEach(categories, id: \.self) { category in
                            Text(category).tag(category)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())  // Use a menu style for the picker
                }
            }
        }.navigationTitle(Text("Add New Expense").font(.largeTitle))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add", action: addExpense)
                        .disabled(isAddDisabled)
                }
            }
    }
    
    // Function to add the expense to the list
    private func addExpense() {
        expenseViewModel.addExpense(name: expenseName, amount: expenseAmount, category: selectedCategory)
        
        dismiss()
    }
    
    var isAddDisabled: Bool {
        return expenseName.isEmpty || expenseAmount == .zero
    }
}

