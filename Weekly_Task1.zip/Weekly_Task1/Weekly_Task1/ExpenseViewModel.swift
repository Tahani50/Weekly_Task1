//
//  Expense.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//

import SwiftUI

// ViewModel to manage the list of expenses
class ExpenseViewModel: ObservableObject {
    @Published var expenses: [Expense] = []         // List of expenses
    @Published var sortedAscending: Bool = true     // Boolean to track if sorting should be ascending or descending
    @Published var selectedCategory: String = "All" // The selected category for filtering expenses
    
    // Function to add expense to the list
    func addExpense(name: String, amount: Double, category: String) {
        let newExpense = Expense(name: name, amount: amount, category: category)
        expenses.append(newExpense)
    }
    
    // Function to toggle the sorting order
    func toggleSortOrder() {
        sortedAscending.toggle()
    }
    
    // Function to filter expenses based on the selected category
    func filteredExpenses() -> [Expense] {
        if selectedCategory == "All" {
            return expenses  // Return all expenses if "All" is selected
        } else {
            return expenses.filter { $0.category == selectedCategory } // Filter by the selected category
        }
    }
    
    // Function to sort expenses by amount
    func sortedExpenses() -> [Expense] {
        return expenses.sorted {
            sortedAscending ? $0.amount < $1.amount : $0.amount > $1.amount
        }
    }
}
