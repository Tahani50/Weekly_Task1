//
//  Weekly_Task1App.swift
//  Weekly_Task1
//
//  Created by Tahani Ayman on 10/09/1446 AH.
//

import SwiftUI

@main
struct Weekly_Task1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
